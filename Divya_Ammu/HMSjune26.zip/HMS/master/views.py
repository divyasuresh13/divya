from django.shortcuts import render,redirect

from django.views.generic import CreateView,ListView,View,View
from master.models import DepartmentModel
from master.forms  import DepartmentForm


# Create your views here.

class CreateDepartmentView(View):
	template_name = 'create_dept.html'
	form_class = DepartmentForm

	def get(self,request):
		form = self.form_class()
		context = {
		'dpt_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			hos_dpt = DepartmentModel.objects.create(
				title = request.POST.get('title'),
				description = request.POST.get('description'),
				hod = request.POST.get('hod'),
				email = request.POST.get('email'),
				contact = request.POST.get('contact')
				)
			return redirect('/gen/home/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})


class ListDepartmentView(View):
	template_name = 'list_dept.html'
	def get(self,request):
		list_dpt = DepartmentModel.objects.all()
		context = {
		'hosp' :list_dpt
		}
		return render(request,self.template_name,context)

class DetailDepartmentView(View):
	template_name = 'dept_details.html'

	def get(self,request,pk):
		obj = DepartmentModel.objects.get(id=pk)
		context = {
		'depart' :obj
		}
		return render(request,self.template_name,context)

class DeleteDepartmentView(View):
	template_name = 'list_dept.html'
	def get(self,request,pk):
		cat_obj = DepartmentModel.objects.get(id=pk).delete()
		list_dept = DepartmentModel.objects.all()
		context = {
		'hosp' :list_dept
		}
		return render(request,self.template_name,context)


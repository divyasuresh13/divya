from django.shortcuts import render,redirect

from django.views.generic import CreateView,ListView,View,View
from master.models import DepartmentModel
from master.forms  import DepartmentForm


# Create your views here.

class CreateDepartmentView(CreateView):
	template_name = 'create_dept.html'
	model = DepartmentModel
	form_class = DepartmentForm
	success_url = '/gen/home/'

class ListDepartmentView(ListView):
	template_name = 'list_dept.html'
	model = DepartmentModel
	context_object_name = 'depts'

class DetailDepartmentView(View):
	template_name = 'dept_details.html'

	def get(self,request,pk):
		obj = DepartmentModel.objects.get(id=pk)
		context = {
		'depart' :obj
		}
		return render(request,self.template_name,context)

class DeleteDepartmentView(View):
	template_name = 'dept_delete.html'
	def get(self,request,pk):
		cat_obj = DepartmentModel.objects.get(id=pk).delete()
		dept_department = DepartmentModel.objects.all()
		context = {
		'depart' :dept_department
		}
		return render(request,self.template_name,context)


from django.shortcuts import render
from django.views.generic import TemplateView,TemplateView
# Create your views here.

class HomePageView(TemplateView):
	template_name = 'index.html'
class AboutUsView(TemplateView):	
	template_name = 'aboutus.html'
class ContactUsView(TemplateView):
	template_name = 'contactus.html'

